//
//  ViewController.swift
//  Timer
//
//  Created by Rp on 23/11/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var timer : Timer!
    var second = 99
    
    @IBOutlet var lbl : UILabel!
    @IBOutlet var lblSecound : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(setUpTime), userInfo: nil, repeats: true)
    }

    @objc func setUpTime(){
        
        second = second - 1
        
        let str = NSString.init(format: "%d", second)
        
        if str.length > 1
        {
            let str1 = str.substring(to: 1)
            let str2 = str.substring(from: 1)
            
            lbl.text = str1
            lblSecound.text = str2
            
        }else{
            lbl.text = "0"
            lblSecound.text = str as String
        }
        if second == 0 {
            timer.invalidate()
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

